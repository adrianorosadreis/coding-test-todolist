﻿namespace ToDoListApi.Enums
{
    public enum TasksStatus
    {
        EmAndamento = 1,
        Pendente = 2,
        Concluida = 3
    }
}